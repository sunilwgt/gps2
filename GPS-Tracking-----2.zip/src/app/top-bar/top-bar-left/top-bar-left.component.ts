import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-bar-left',
  templateUrl: './top-bar-left.component.html',
  styleUrls: ['./top-bar-left.component.scss']
})
export class TopBarLeftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
