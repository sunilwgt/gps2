import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TopBarComponent } from './top-bar/top-bar.component';
import { TopBarLeftComponent } from './top-bar/top-bar-left/top-bar-left.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { MainBodyComponent } from './main-body/main-body.component';
import { SidePanelComponent } from './main-body/side-panel/side-panel.component';

@NgModule({
  declarations: [
    AppComponent,
    TopBarComponent,
    TopBarLeftComponent,
    MainBodyComponent,
    SidePanelComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule.forRoot(),
    AngularFontAwesomeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
